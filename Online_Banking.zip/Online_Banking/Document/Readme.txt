1.Open index.html file.
2.From this you can go to any link.
3.The project has login.php which is used to login to Online_Banking.